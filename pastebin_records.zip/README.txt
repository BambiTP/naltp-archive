NALTP archive - the matches saved to pastebin
=============================================

tagproleague.com links a pastebin instead of a tagpro.eu match for some league games: matches
tagpro.eu doesn't have. Whoever posted a pastebin can delete it, so every one the archive found is
saved here.

pages/<id>.txt      the pastebin page exactly as it was fetched. Two kinds turn up: the whole
                    tagpro.eu match document (server, group, date, duration, map, teams, players
                    with their events), and a stats sheet (one row per player: team, minutes,
                    score, tags, pops, grabs, drops, hold, captures, prevent, returns, powerups).
records/<id>.json   the same page read into one shape: kind, date, minutes, map, and two teams,
                    each with its name, score and players. Where enough of the line-up matches a
                    roster, the team it belongs to is named and "teams_matched" is true.
pastebin_games.csv  one row per game a pastebin holds, with the season, week, the two teams, which
                    game of the matchup, the score, how many players each side has, and the link.
                    A page with fewer than three players on a side is a placeholder, not a record.

The archive reads them at <https://bambitp.github.io/naltp-archive/> - match.html?id=<id> shows one.
